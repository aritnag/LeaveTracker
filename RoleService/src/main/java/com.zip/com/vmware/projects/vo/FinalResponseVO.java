package com.vmware.projects.vo;

import java.util.List;

public class FinalResponseVO {

	private CategoryResponseVO category;

	public CategoryResponseVO getCategory() {
		return category;
	}

	public void setCategory(CategoryResponseVO category) {
		this.category = category;
	}
}
