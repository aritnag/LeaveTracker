package com.vmware.projects.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class UserDetailsByLeaves {

	private List<User> user;
	private LeaveVO leaveDetails;
	public List<User> getUser() {
		return user;
	}
	public void setUser(List<User> user) {
		this.user = user;
	}
	public LeaveVO getLeaveDetails() {
		return leaveDetails;
	}
	public void setLeaveDetails(LeaveVO leaveDetails) {
		this.leaveDetails = leaveDetails;
	}
}
